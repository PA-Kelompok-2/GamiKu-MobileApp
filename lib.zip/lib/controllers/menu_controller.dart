import 'package:get/get.dart';
import '../core/services/supabase_services.dart';
import '../../../core/utils/app_snackbar.dart';

class MenuC extends GetxController {
  final SupabaseService service = SupabaseService();

  var menus = <Map<String, dynamic>>[].obs;
  var categories = <Map<String, dynamic>>[].obs;
  var isLoading = true.obs;

  RxString selectedCategory = ''.obs;

  List<Map<String, dynamic>> allMenus = [];

  void resetMenu() async {
    selectedCategory.value = "Semua";
    await fetchMenus();
  }

  @override
  void onInit() {
    fetchMenus();
    fetchCategories();
    super.onInit();
  }

  Future<void> fetchMenus() async {
    try {
      isLoading.value = true;

      final data = await service.getMenus();

      final mappedMenus = data.map((e) {
        return {
          'id': e['id'],
          'name': e['name'],
          'price': e['price'],
          'image_url': e['image_url'],
          'category_id': e['category_id'],
          'cat': e['categories']?['name'] ?? 'unknown',
        };
      }).toList();

      menus.value = mappedMenus;
      allMenus = mappedMenus;
    } catch (e) {
      showErrorSnackbar(
        'Error',
        'Failed to fetch menus: $e'
      );
    } finally {
      isLoading.value = false;
    }
  }

  void applyFilter(String query) {
    final q = query.toLowerCase();

    final filtered = allMenus.where((menu) {
      final name = menu['name'].toString().toLowerCase();
      final cat = menu['cat'].toString().toLowerCase();
      final selectedCat = selectedCategory.value.toLowerCase();

      if (q.isNotEmpty) {
        return name.contains(q);
      }

      if (selectedCat.isEmpty || selectedCat == "semua") {
        return true;
      }

      return cat == selectedCat;
    }).toList();

    menus.value = filtered;
  }

  void filterByCategory(String category) {
    selectedCategory.value = category;

    if (category == "Semua" || category.isEmpty) {
      menus.value = allMenus;
      return;
    }

    final filtered = allMenus.where((menu) => menu['cat'] == category).toList();

    menus.value = filtered;
  }

  Future<void> fetchCategories() async {
    try {
      final data = await service.getCategories();
      categories.value = data;
    } catch (e) {
      showErrorSnackbar(
        'Error',
        'Failed to fetch categories: $e'
      );
    }
  }

  Future<void> addMenu({
    required String name,
    required int price,
    String? imageUrl,
    required String categoryId,
  }) async {
    try {
      await service.addMenu(
        name: name,
        price: price,
        imageUrl: imageUrl,
        categoryId: categoryId,
      );

      await fetchMenus();
      menus.refresh();

      showSuccessSnackbar('Success', 'Menu berhasil ditambahkan');
    } catch (e) {
      showErrorSnackbar(
        'Error',
        'Failed to add menu: $e'
      );
    }
  }

  Future<void> updateMenu({
    required dynamic id,
    required String name,
    required int price,
    String? imageUrl,
    required String categoryId,
  }) async {
    try {
      await service.updateMenu(
        id: id,
        name: name,
        price: price,
        imageUrl: imageUrl,
        categoryId: categoryId,
      );

      await fetchMenus();
      menus.refresh();

      showSuccessSnackbar('Success', 'Menu berhasil diupdate');
    } catch (e) {
      showErrorSnackbar(
        'Error',
        'Failed to update menu: $e'
      );
    }
  }

  Future<void> deleteMenu(dynamic id) async {
    try {
      await service.deleteMenu(id);

      menus.removeWhere((m) => m['id'] == id);
      menus.refresh();

      await fetchMenus();

      showSuccessSnackbar('Success', 'Menu berhasil dihapus');
    } catch (e) {
      showErrorSnackbar(
        'Error',
        'Failed to delete menu: $e'
      );
    }
  }

  Future<void> updateAvailability(String id, bool isAvailable) async {
    try {
      await service.updateMenuAvailability(id, isAvailable);

      final index = menus.indexWhere((m) => m['id'].toString() == id);

      if (index != -1) {
        menus[index] = {...menus[index], 'is_available': isAvailable};

        menus.refresh();
      }
    } catch (e) {
      showErrorSnackbar(
        'Error',
        'Gagal update status: $e'
      );
    }
  }
}
